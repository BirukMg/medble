module.exports = function (app) {
  var passportFacebook = require('../auth/facebook');
  var passportGoogle = require('../auth/google');

  app.get('/facebook', passportFacebook.authenticate('facebook', {
      scope: ["email"]
  }));
  app.get('/google',passportGoogle.authenticate('google', {
    scope: ["email", "profile"],
  }));

  app.get('/facebook/callback', 
  passportFacebook.authenticate('facebook', {
    failureRedirect: 'http://localhost:3000'
  }),
  function(req, res) {
    // Successful authentication, redirect home.
    res.redirect('http://localhost:3000');
  });

  app.get('/google/callback',
    passportGoogle.authenticate('google', {
      failureRedirect: 'http://localhost:3000',
    }),
    function(req, res) {
      res.redirect('http://localhost:3000');
    });

  
}