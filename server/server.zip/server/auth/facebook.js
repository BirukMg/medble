var passport = require('passport')
  , FacebookStrategy = require('passport-facebook').Strategy;
var User = require('../../common/models/medble-user');

passport.use(new FacebookStrategy({
    clientID: "378529259488725",
    clientSecret: "79c37839829724499615ce20e2324ffb",
    callbackURL: "http://127.0.0.1:8080",
  },
  function(accessToken, refreshToken, profile, done) {
    User.findOrCreate({name: profile.displayName}, {name: profile.displayName,userid: profile.id}, function(err, user) {
      if (err) { return done(err); }
      console.log(user);
      done(null, user);
    });
  }
));

module.exports = passport;