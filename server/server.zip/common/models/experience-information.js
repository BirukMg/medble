'use strict';

module.exports = function(Experienceinformation) {

};
