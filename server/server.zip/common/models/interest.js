'use strict';

module.exports = function(Interest) {

};
