'use strict';

module.exports = function(Event) {

};
