'use strict';

module.exports = function(Resume) {

};
