'use strict';

module.exports = function(Medbleuser) {

};
