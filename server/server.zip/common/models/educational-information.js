'use strict';

module.exports = function(Educationalinformation) {

};
