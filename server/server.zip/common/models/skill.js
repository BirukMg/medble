'use strict';

module.exports = function(Skill) {

};
