'use strict';

module.exports = function(Employment) {

};
