'use strict';

module.exports = function(Vehicle) {

};
