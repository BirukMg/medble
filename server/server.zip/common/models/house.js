'use strict';

module.exports = function(House) {

};
